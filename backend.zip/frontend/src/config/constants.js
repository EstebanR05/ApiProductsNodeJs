// export const API_BASE_URL = 'http://localhost:4000/api';
export const API_BASE_URL = 'https://productsbackend.onrender.com/api';

export const ENDPOINTS = {
    PRODUCTS: `${API_BASE_URL}/products`,
}; 